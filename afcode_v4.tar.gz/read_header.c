#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include"fitsio.h"

#include "types.h"


void read_header( char *filename,int *width, int *height,int  *bitpix,double *bscale,double *bzero,int fimg)
{
    fitsfile *fptr;     
    int nfound, status = 0;
    char comm[81]; 
    long naxes[2], bitpix_l;
    double bscale_d=1, bzero_d=0;
    double crpix[2],crval[2],cd1[2],cd2[2];

    if ( fits_open_file(&fptr, filename, READONLY, &status) )
    {
	printf("Cannot open file: %s %i\n", filename,status);
	exit(0);
    }

    fits_read_keys_lng(fptr, "NAXIS", 1, 2, naxes, &nfound, &status);

    fits_read_key_lng(fptr, "BITPIX", &bitpix_l, comm, &status);

    if(fits_read_key_dbl(fptr, "BSCALE",&bscale_d,comm, &status))
    {
	printf("#setting BSCALE to 1 \n");
	status=0;
    }

    if(fits_read_key_dbl(fptr, "BZERO",&bzero_d,comm, &status))
    {
	printf("#setting BZERO to 0 \n");
	status=0;
    }

    //Only for the input science images not for the mask
    if(fimg)
    {
	fits_read_keys_dbl(fptr, "CRPIX", 1, 2, crpix, &nfound, &status);
	if(!nfound)
	{
	    printf("WARNING: CRPIX not found in the header \n");
	    exit(0);
	}
	fits_read_keys_dbl(fptr, "CRVAL", 1, 2, crval, &nfound, &status);
	if(!nfound)
	{
	    printf("WARNING: CRVAL not found in the header \n");
	    exit(0);
	}
	fits_read_keys_dbl(fptr, "CD1_", 1, 2, cd1, &nfound, &status);
	if(!nfound)
	{
	    printf("WARNING: CD1 not found in the header \n");
	    exit(0);
	}
	fits_read_keys_dbl(fptr, "CD2_", 1, 2, cd2, &nfound, &status);
	if(!nfound)
	{
	    printf("WARNING: CD2 not found in the header \n");
	    exit(0);
	}
	astro_struct.crpix1=crpix[0];
	astro_struct.crpix2=crpix[1];
	astro_struct.crval1=crval[0];
	astro_struct.crval2=crval[1];
	astro_struct.cd1_1=cd1[0];
	astro_struct.cd1_2=cd1[1];
	astro_struct.cd2_1=cd2[0];
	astro_struct.cd2_2=cd2[1];
    }

    *bitpix=(int )bitpix_l;
    *bscale=bscale_d;
    *bzero=bzero_d;
    *width=(int )naxes[0];
    *height=(int )naxes[1];

    printf("#Reading FITS header: total width: %i total height: %i bitpix: %i\n", *width, *height, *bitpix);
    
    if ( fits_close_file(fptr, &status) )
    {
	printf("Cannot close file: %s %i\n", filename,status);
	exit(0);
    }

    return ;
}
