#include<stdio.h>
#include<math.h>
#include<malloc/malloc.h>
#include<stdlib.h>
#include<time.h>

#include "types.h"

#ifdef _OPENMP
	#include<omp.h>
#else
	#define omp_get_num_threads() 0
	#define omp_get_thread_num() 0
#endif


DATA_TYPE *smooth(DATA_TYPE *im,int width,int height, char *thname)
{
    DATA_TYPE *imc,*temp;
    int       i,mesh,j,k,meshth,debug;
    double    c,wscale,wscaleth;
    //char name[256];

    imc=(DATA_TYPE *)malloc(width*height*sizeof(DATA_TYPE));
    temp=(DATA_TYPE *)malloc(width*height*sizeof(DATA_TYPE));


    FILE *cata;
    cata=fopen(thname,"r");
    fscanf(cata,"%i %lg %i",&meshth,&wscaleth,&debug);
    fclose(cata);
    printf("#Input thresholds for smoothing: %i %lg %i\n",meshth,wscaleth,debug);


    //**thresholds
    wscale=wscaleth;
    mesh=meshth;

    //CFHT setting
    /* wscale=3.0;
       mesh=4;
     */

    // printf("pouet: %i %i\n",width,height); 
    clock_t t0, t1;
    t0=clock();
    #pragma omp parallel private(i,j,k,c) shared(width,height,mesh,im,temp,imc)
    {
	#pragma omp master
	{
	    printf("#No. of processors used: %d \n",omp_get_num_threads());
	}
	#pragma omp for
	for(i=0;i<width;i++)
	    for(j=0;j<height;j++)
	    {
		if(i>mesh && i <width-mesh && j>-1 && j<height)
		{
		    c=0.0;
		    for(k=-mesh;k<=mesh;k++)
		    {
			c += im[i+k+width*(j)]*exp(-(double)(k*k)/wscale);
		    }
		    temp[i+width*j]=c;
		}
		else temp[i+width*j]=im[i+width*j];
	    }
	#pragma omp for
	for(i=0;i<width;i++)
	    for(j=0;j<height;j++)
	    {
		if(i>-1 && i <width-1 && j>mesh && j<height-mesh)
		{
		    c=0.0;
		    for(k=-mesh;k<=mesh;k++)
		    {
			c += temp[i+width*(j+k)]*exp(-(double)(k*k)/wscale);
		    }
		    imc[i+width*j]=c;
		}
		else imc[i+width*j]=im[i+width*j];
	    }

	#pragma omp for
	for(i=0;i<width;i++)
	    for(j=0;j<height;j++)
	    {
		if(i>mesh && i <width-mesh && j>-1 && j<height)
		{
		    c=0.0;
		    for(k=-mesh;k<=mesh;k++)
		    {
			c += im[i+k+width*(j)]*exp(-(double)(k*k)/(wscale*2.0));
		    }
		    temp[i+width*j]=c;
		}
		else temp[i+width*j]=im[i+width*j];
	    }

	#pragma omp for
	for(i=0;i<width;i++)
	    for(j=0;j<height;j++)
	    {
		if(i>-1 && i <width-1 && j>mesh && j<height-mesh)
		{
		    c=0.0;
		    for(k=-mesh;k<=mesh;k++)
		    {
			c += temp[i+width*(j+k)]*exp(-(double)(k*k)/(wscale*2.0));
		    }
		    imc[i+width*j] -= 0.5*c;
		}
		else imc[i+width*j]=im[i+width*j];
	    }
    }

    printf("#Smoothed the image with a kernel\n");
    t1=clock();
    printf("#Timing: %fs \n", (const float)(t1-t0)/CLOCKS_PER_SEC);
    
    if(debug)  
    {
	writefits(imc, "ar_sm.fits", width, height);  
	printf("#Writing ar_sm.fits \n");
    }

    free(temp);

    return imc;
}
