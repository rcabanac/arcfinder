#include<stdio.h>
#include<string.h>
#include<malloc/malloc.h>
#include<stdlib.h>
#include "types.h"
#include <ctype.h>
#include<math.h>


int main(int argc,char *argv[])
{
    void      connect();
    FILE      *file,*ifile;
    int       i,width,height,buffer,bitpix,s_width,s_height,fimg,
	      x0,y0;
    char  gname[256],iname[256],outname[256]="n_arc.data",outname1[256]="arcpos.data",outname2[256],mname[256],thname[256]="thresh.data",*im_l,iflag,fcat,fmask;
    DATA_TYPE *im,*im_c,*imc,*im_i,*im_mask;
    double    bscale,bzero,sigma,sigma2,usr_sig;
    float     *im_d;

    usr_sig=-99.0; 


    prout=0;
    iflag=0;
    fcat=0;
    fmask=0;


    printf("################################################## \n");
    for (i=1; i<argc; i++)
	switch(tolower(argv[i][1]))
	{
	    case 'g': sprintf(gname,"%s",argv[++i]);   // inp filename (primary band)
		      break;
	    case 'i': sprintf(iname,"%s",argv[++i]); //filename (sec. band) optional 
		      iflag=1;
		      break;
	    case 'p': prout=1;
		      break;
	    case 'x': x0=atoi(argv[++i]);    
		      break;
	    case 'y': y0=atoi(argv[++i]);    
		      break;
	    case 'w': s_width=atoi(argv[++i]); 
		      break;
	    case 'h': s_height=atoi(argv[++i]); 
		      break;
	    case 'o': sprintf(outname,"%s",argv[++i]); // tabulated arcfinder output
		      break;
	    case 's': sprintf(outname1,"%s",argv[++i]); //filename - lists all the pixels belonging to each arc candidate 
		      break;
	    case 'c': sprintf(outname2,"%s",argv[++i]);  // catalog filename (not in use) 
		      fcat=1;
		      break;
	    case 'n': usr_sig=(double)atof(argv[++i]); // user provided sigma - image noise
		      break;
	    case 'm': sprintf(mname,"%s",argv[++i]);   // mask filename
		      fmask=1;
		      break;
	    case 't': sprintf(thname,"%s",argv[++i]);   // threshold setting filename
		      break;
	}
   

   // Check if the paths to the files and the required files exist
    char cmd[256];
    sprintf(cmd,"touch %s > /dev/null 2>&1",outname);
    if(system((const char *)cmd))
    {
	printf("Path to %s does not exist \n",outname);
	exit(0);
    }
    
    sprintf(cmd,"touch %s > /dev/null 2>&1",outname1);
    if(system((const char *)cmd))
    {
	printf("Path to %s does not exist \n",outname1);
	exit(0);
    }

    if(fcat==1)
    {
	if( !(file=fopen(outname2,"r"))) 
	{
	    printf("Cannot find/open file: %s\n", outname2); 
	    exit(0);
	}
	else fclose(file);
    }

    if(iflag==1)
    {
	if( !(file=fopen(iname,"r"))) 
	{
	    printf("Cannot find/open file: %s\n", iname); 
	    exit(0);
	}
	else fclose(file);
    }

    if(fmask==1)
    {
	if( !(file=fopen(mname,"r"))) 
	{
	    printf("Cannot find/open file: %s\n", mname); 
	    exit(0);
	}
	else fclose(file);
    }

    if(!(file=fopen(thname,"r"))) 
    { 
	printf("Cannot find/open file: %s\n", thname); 
	exit(0);
    }
    else fclose(file);

    /****************************************************************************************/
    /******* Lecture du FITS ****************************************************************/
    /****************************************************************************************/
    
    fimg=1;
    read_header(gname,&width,&height,&bitpix,&bscale,&bzero,fimg);

    if(x0<1 || y0<1 || x0>width || y0>height ){printf("Center x0 y0 is out of image! Adjust the center.");exit(0);}
    
    if ((s_width%2==0 && x0+s_width/2>width) || (s_width%2==1 && x0+s_width/2>width-1) || (s_height%2==0 &&  y0+s_height/2>height) || (s_height%2==1 &&  y0+s_height/2>height-1) || x0-s_width/2<0 || y0-s_height/2 < 0) 
    {
	printf("Window size falls out of the image. Change the size of the region to be searched or shift the center. \n"); 
	exit(0);
    }
    
    printf("#Centered at %i,%i  ",x0,y0 );

    int flgx=500, flgy=500;
    //#########for the x-coordinate##### 
    if ((s_width==width || s_width==width-1) && x0==width/2)
    {
	if(width%2==0 && s_width%2==0) {s_width=s_width-1;} 
	if(width%2==1 && s_width%2==0) {s_width=s_width+1;} 
  	x0=1;
	flgx=1;
	goto det1;
    }
    
    if(s_width%2==0 && s_width<width) { s_width=s_width+1; }
    
    
    //#########for the y-coordinate##### 
    det1:
    if ((s_height==height || s_height==height-1) && y0==height/2)
    {
	if(height%2==0 && s_height%2==0) { s_height=s_height-1;}
	if(height%2==1 && s_height%2==0) { s_height=s_height+1;}
  	y0=1;
	flgy=1;
	goto det2;
    }

    if(s_height%2==0 && s_height<height) { s_height=s_height+1; } 
    
//  //finding ymin;
//  if (y0 - s_height/2>1) y0mincand=y0-s_height/2; 
//  
//  //finding ymax;
//  if (y0 + s_height/2>=height && height%2==1) y0maxcand=height;
//  if (y0 + s_height/2>=height && height%2==0) y0maxcand=height-1;
//  
//  if (y0 + s_height/2<height && s_height%2==1) y0maxcand=(y0mincand==1 ? s_height :y0mincand+s_height);
//  if (y0 + s_height/2<height && s_height%2==0) y0maxcand= y0mincand+s_height-1;
    //################
    

    det2:
    //Define the bottom left corner of the image
    if(flgx!=1) x0 = x0 - s_width/2 ;
    if(flgy!=1) y0 = y0 - s_height/2 ;
    
    printf ("with a window of %i x %i \n",s_width,s_height); 
    //printf ("botleft %i %i %i %i\n",x0,y0,x0+s_width,y0+s_height); 

    buffer=128; 
    //Use the value of the sigma directly, if provided by the user
    sigma=usr_sig;
    sigma2=usr_sig;
    
    //Read the input image
    im=read_image(gname,width,height,s_width,s_height,x0,y0,bitpix,bscale,bzero,&sigma);
    printf("#Done reading image: %s\n",gname);
    printf("######################### \n");
    
    //Smooth the input image with a Mexican hat filter
    imc=smooth(im,s_width,s_height,thname);
    printf("######################### \n");

    //Calculate the elongation estimator
    im_d=detect(imc,s_width,s_height,im_l,sigma,thname);
    printf("######################### \n");

    // Read mask file (in FITS or ascii format), if provided
    char check[6];
    strncpy(check,(const char *)(mname+strlen(mname)-5),5);

    if(fmask)
    {
	if(!(strstr(check, ".fits")==NULL && strstr(check, ".FITS")==NULL))
	{
	    fimg=0;
	    read_header(mname,&width,&height,&bitpix,&bscale,&bzero,fimg);
	    
	    if(width%2==0 && (s_width!=width-1 || s_height!=height-1) )
	    {
		printf("WARNING: The mask image size is not the same as the input image size, proceeding anyway \n");
	    }
	    if(width%2==1 && (s_width!=width || s_height!=height) )
	    {
		printf("WARNING: The mask image size is not the same as the input image size, proceeding anyway \n");
	    }
	    
	    im_mask=read_image(mname,width,height,s_width,s_height,x0,y0,bitpix,bscale,bzero,&sigma2);
            printf("#Done reading the mask file: %s\n",mname);
	    printf("######################### \n");
	}
	else
	{   
	    int ii,jj,in=0,xm,ym;
	    float mval,mval1;
	    im_mask = (DATA_TYPE *)malloc(s_width*s_height*sizeof(DATA_TYPE));
	    
	    ifile=fopen(mname,"r"); 
	    for(jj=0;jj<height;jj++)
	    {
		for(ii=0;ii<width;ii++)
		{
		    fscanf(ifile,"%i %i %f",&ym,&xm,&mval);
		    if(xm>=x0 && xm<x0+s_width && ym>=y0 && ym<y0+s_height)
		    {
			im_mask[in++]=(DATA_TYPE)(mval);
		    }
		}
	    }
	    fclose(ifile);
            
	    printf("#Done reading the mask file: %s\n",mname);
	    printf("######################### \n");
	}
    }
    
    // Read the second input image, if provided
    if(iflag)
    {
	fimg=1;
	read_header(iname,&width,&height,&bitpix,&bscale,&bzero,fimg);
	im_i=read_image(iname,width,height,s_width,s_height,x0,y0,bitpix,bscale,bzero,&sigma2);
        printf("#Done reading the second input image file: %s\n",iname);
        printf("######################### \n");
    }

    //Connect the pixels of the candidate arc and determine its properties
    connect(im,im_i,im_mask,imc,im_d,s_width,s_height,x0,y0,sigma,iflag,fmask,outname,outname1,outname2,thname);
    printf("#Writing %s and %s \n", outname, outname1);
    printf("################################################## \n");

    return 0;

}
