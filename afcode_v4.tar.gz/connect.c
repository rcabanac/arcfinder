#include<stdio.h>
#include<string.h>
#include<malloc/malloc.h>
#include<stdlib.h>
#include<math.h>

#include "types.h"

float pi=3.141592653589793;

/*void sort(int n, float *arr);
  void ksone(float *data, int n, float (*func)(float), float *d,float *prob);

  float func(float x)
  {
  return x;
  }
 */
void sort2(int n, float *arr, int*num);

int loopcalc(int ii,int jj,int i0,int j0,int width,int height,int *n_lisim,int n_liste,int *liste_x, int *liste_y,int *lisim_x, int *lisim_y, char *im2,char *im3,float *im_in,float *im0,int flag1,double crit1,double crit2)
{
    int loopflag=0;
    /* int buffer,n_buffer_l;
       buffer=10000;
       n_buffer_l=buffer;
     */ 
    int k=ii+i0+width*(jj+j0);
    if(ii+i0>0 && ii+i0<width-1 && jj+j0<height-1 && jj+j0>0 && im3[k] )
    {
	if(!im3[k-1] || !im3[k+1] || !im3[k-width] || !im3[k+width] || !im3[k-width-1] || !im3[k-width+1] || !im3[k+width-1] || !im3[k+width+1])  flag1=1;
	else flag1=0;

	if((im_in[k] > crit1 && im0[k] > crit2 ) && flag1 )//
	{
	    lisim_x[*n_lisim]=ii+i0;
	    lisim_y[*n_lisim]=jj+j0;
	    *n_lisim=*n_lisim+1;
	    if(*n_lisim > 1000 || n_liste >1000) 
	    { 
		loopflag=1; 
		return loopflag;
	    }
	    //** OBSOLETE re-malloc to extend buffer
	    /*   if(n_lisim > n_buffer_l-1) 
		 {
		 n_buffer_l += buffer; 
		 lisim_x=(int *)realloc(lisim_x,n_buffer_l*sizeof(int));
		 lisim_y=(int *)realloc(lisim_y,n_buffer_l*sizeof(int));
		 }

		 if(n_liste > n_buffer_l-1) 
		 {
		 n_buffer_l += buffer; 
		 liste_x=(int *)realloc(liste_x,n_buffer_l*sizeof(int));
		 liste_y=(int *)realloc(liste_y,n_buffer_l*sizeof(int));
		 }
	     */

	    im3[k]=0;
	    im2[k]=0;
	}
    }

    return loopflag;
}

int ibandcalc(float Ex, float Ey,int xb,int yb,float del_x,float del_y,int width,int height,float *im_in,float *im_in_i,double mean_im,double mean_im_i)
{
    float ms0=0.;
    int xw=xb+2,yw=yb+2,x0_c=0,y0_c=0, bcnt=0;
    double r0_m=0.;
    // xw=xb+1; yw=Ey-(del_x/del_y)*(xw-Ey);
    if(fabs(Ex-xb)<1. && fabs(Ey-yb)<1.) 
    {
	if(fabs(1.*del_y) <=1.) ms0=del_x/(del_y+1.e-4);
	ms0=del_x/del_y;

    }
    else if(fabs(xb-Ex)>=fabs(yb-Ey)) { ms0=(yb-Ey)*1./(xb-Ex)*1.;}
    else if(fabs(xb-Ex)<fabs(yb-Ey)) { ms0=(xb-Ex)*1./(yb-Ey)*1.;}

    while(r0_m<44.)
    {
	if(fabs(xb-Ex)>=fabs(yb-Ey))
	{
	    if(Ex>=xb)  xw=xw+5;
	    else if(Ex<xb) xw=xw-5;
	    yw=(ms0*(xw-xb)) + yb;
	}
	else if(fabs(xb-Ex)<fabs(yb-Ey))
	{
	    if(Ey>=yb)  yw=yw+5;
	    else if(Ey<yb) yw=yw-5;
	    xw=(ms0*(yw-Ey)) + Ex;
	}

	//printf("%i %i \n",xw+x0,yw+y0);
	r0_m=sqrt((xw-xb)*(xw-xb)+(yw-yb)*(yw-yb)); 
	if(xw<1 || yw<1 || xw>width-1 || yw>height-1) break; 
	double c_i=0., c=0.;

	for(x0_c=xw-2;x0_c<xw+2;x0_c++)
	    for(y0_c=yw-2;y0_c<yw+2;y0_c++)
	    { 
		c+=im_in[x0_c+width*y0_c];
		c_i+=im_in_i[x0_c+width*y0_c];
	    }

	c/=(double)25.;
	c_i/=(double)25.;
	if(c_i/c>2.0*mean_im_i/mean_im ) bcnt=bcnt+1;
    }
    return bcnt;
} 

void connect(DATA_TYPE *im_in,DATA_TYPE *im_in_i, DATA_TYPE *im_mask,DATA_TYPE *im0,DATA_TYPE *im,int width,int height,int x0,int y0,double sigma,char iflag, char imask, char *outname, char *outname1, char *outname2, char *thname)
{
    int     i,j,ii,jj,*new_x,*new_y,*liste_x,*liste_y, *lisim_x, *lisim_y, *old_x, *old_y,
	    buffer,n_buffer,n_buffer_l,k,i0,j0,n,n0,ik,n_liste,
	    x,y,x_min,y_min,x_max,y_max,delta_x,delta_y,xg_i,yg_i,
	    borne1_x,borne2_x,borne1_y,borne2_y,last_alloc,subw;
    float   *temp1,dd;
    char    *im2,*im3;
    double  xg,yg,mean_im,min_im,max_im,c, r0_s,mean_im_i=-99.,mean_im0=-99.;
    FILE    *cata, *cata1;
   // FILE    *cata2;
    int mflag=-99;

    //For debugging set these to 1 for verbose printing
    int debug=0,debug1=0;

    //Memory allocation
    buffer=10000;
    new_x=(int *)malloc(buffer*sizeof(int));
    new_y=(int *)malloc(buffer*sizeof(int));
    liste_x=(int *)malloc(buffer*sizeof(int));
    liste_y=(int *)malloc(buffer*sizeof(int));
    n_buffer=buffer;
    n_buffer_l=buffer;
    im2=(char *)malloc(width*height*sizeof(char));
    im3=(char *)malloc(width*height*sizeof(char));
    last_alloc=buffer;
    old_x=(int *)malloc(buffer*sizeof(int));
    old_y=(int *)malloc(buffer*sizeof(int));
    lisim_x=(int *)malloc(buffer*sizeof(int));
    lisim_y=(int *)malloc(buffer*sizeof(int));
    temp1=(float *)malloc(width*height*sizeof(float));
    int o_buffer=buffer,sr;

    printf("#Constructing arc candidates \n");

    //*******Initialising parallely two image arrays**** 
    for(i=0;i<width*height;i++) im2[i]=1;
    for(i=0;i<width*height;i++) im3[i]=1;

    //Reading threshold file
    int jnk;
    float jnk1;
    int mmth,n_listeth,n_lisimth,subwth,winth;
    float seuilth,max_imth,mean_imth,l_arcth,w_arcth,crit1th,crit2th,widminth,widmaxth;
    cata=fopen(thname,"r");
    fscanf(cata,"%i %f %i %i %f %i %i %f %i %f %f %i %f %f %f %f %i %i %f %f %i",&jnk,&jnk1,&jnk,&jnk,&jnk1,&jnk,&mmth,&seuilth,&n_listeth,&max_imth,&mean_imth,&subwth,&l_arcth,&w_arcth,&crit1th,&crit2th,&winth,&n_lisimth,&widminth,&widmaxth,&debug);
    fclose(cata);

    printf("#Input thresholds for connecting the arc and measuring its properties: %i %g %i %g %g %i %g %g %g %g %i %i %g %g %i \n",mmth,seuilth,n_listeth,max_imth,mean_imth,subwth,l_arcth,w_arcth,crit1th,crit2th,winth,n_lisimth,widminth,widmaxth,debug);
  
    
    //Opening output files to write
    cata1=fopen(outname1,"w");
    cata=fopen(outname,"w");


    //**threshold
    //int mm=4;                     
    //float seuil=1.10;    //$$seuil=1.25; 

    int mm=mmth;
    float seuil=seuilth;

    int nbarc=1; 
    int n_lisim=0;
    
    if(debug==2) printf("###### Help ####### \n");
    if(debug==2) printf("#xb,yb:extreme points - xlow,xhigh,ylow,yhigh,xbase,ybase,delx,dely \n");
    if(debug==2)  printf("#arc chord-length: xbase, ybase, chord length, r_curv \n"); 
    if(debug) printf("#Accepting: xpeak, ypeak, r_curv, mean_im/sigma, length, width(=area/length), length/width, number \n");
    if(debug==2) printf("################### \n");
    //*******First loop: connect pixels with elongation estimator above a threshold*******    
    for(i=0;i<width;i++)
    {
	if((i/500)*500 == i) printf("#connect: %i\n",i);

	for(j=0;j<height;j++)
	{
            start: //printf("skipping at %i %i \n",i,j);  
	    n=1;
	    new_x[0]=i;
	    new_y[0]=j;
	    n_liste=0;
	    n_lisim=0;

	    if(im[i+width*j]>seuil && im2[i+width*j])
	    {
		while(n>0)
		{
		    n0=n;
		    for(sr=0;sr<n;sr++)
		    {
			old_x[sr]=new_x[sr];
			old_y[sr]=new_y[sr];
			if(sr > o_buffer-1) {  o_buffer += buffer;
			    old_x=realloc(old_x,o_buffer*sizeof(int));
			    old_y=realloc(old_y,o_buffer*sizeof(int));}
		    }
		    n=0;
		    for(ik=0;ik<n0;ik++)
		    {
			i0=old_x[ik];
			j0=old_y[ik];

			for(ii=-mm;ii<=mm;ii++)
			    for(jj=-mm;jj<=mm;jj++)
			    {
				k=ii+i0+width*(j0+jj);
				if(ii+i0>-1 && ii+i0<width && jj+j0<height && jj+j0>-1 && im2[k] ) //&& im3[k])
				{
				    if(im[k]>seuil )
				    {
					new_x[n]=ii+i0;
					new_y[n++]=jj+j0;
					//printf("pos %i %i \t",new_x[n-1],new_y[n-1]); 
					if(n_liste>1000) goto start; 

					if(n > n_buffer-1) 
					{  n_buffer += buffer; 
					    new_x=realloc(new_x,n_buffer*sizeof(int));
					    new_y=realloc(new_y,n_buffer*sizeof(int));
					}
					liste_x[n_liste]=ii+i0;
					liste_y[n_liste++]=jj+j0;

					lisim_x[n_lisim]=ii+i0;
					lisim_y[n_lisim++]=jj+j0;
					if(n_liste > n_buffer_l-1) 
					{n_buffer_l += buffer; 
					    liste_x=(int *)realloc(liste_x,n_buffer_l*sizeof(int));
					    liste_y=(int *)realloc(liste_y,n_buffer_l*sizeof(int));
					}
					if(n_lisim > n_buffer_l-1) 
					{n_buffer_l += buffer; 
					    lisim_x=(int *)realloc(lisim_x,n_buffer_l*sizeof(int));
					    lisim_y=(int *)realloc(lisim_y,n_buffer_l*sizeof(int));
					}
					im2[k]=0;
					im3[k]=0;
				    }

				}
			    }
		    }
		}
	    }
	    

	    //***First loop result: n_liste - number of pixels belonging to the skeleton of arc*****
	    int flag1=0;double c_i,c_0; 
	    double mean_ratgi=0.;

	    //**threshold
	    //if(n_liste>10) 
	    if(n_liste>n_listeth) 
	    { 

		//*****Calculate peak position, peak value and mean flux of this arc******
		x_min=x_max=liste_x[0];
		y_min=y_max=liste_y[0];
/*
                x_min=100000;
                x_max=0;
                y_min=100000;
                y_max=0;
*/
		xg=yg=mean_im=0.0;
		min_im=1.0e22;
		max_im=-1.0e22;

		//int xen=liste_x[0],xex=liste_x[0],yen=liste_y[0],yex=liste_y[0];

		for(ii=0;ii<n_liste;ii++)
		{
		    x=liste_x[ii];
		    y=liste_y[ii];
	            //printf("%i %i \n", x,y);
		    //added by anu//
		    if(x<x_min) {x_min=x;} //yen=lisim_y[ii];}
		    if(y<y_min) {y_min=y;} //xen=lisim_x[ii];}
		    if(x>x_max) {x_max=x;} //yex=lisim_y[ii];}
		    if(y>y_max) {y_max=y;} //xex=lisim_x[ii];}

		    xg += x;
		    yg += y;
		}
	        //printf("DEBUG: %i %i %i %i\n", x_min,y_min,x_max,y_max);
		xg /= (double)n_liste;
		yg /= (double)n_liste;

		delta_x=x_max-x_min;
		delta_y=y_max-y_min;

		xg_i=floor(xg);
		if(xg-xg_i>0.5) xg_i=ceil(xg);
		yg_i=floor(yg);
		if(yg-yg_i>0.5) yg_i=ceil(yg);

		//***Calculate mean flux for the first image, and second band image, if provided ***
		int x_peak, y_peak;
		for(ii=0;ii<n_liste;ii++){
		    x=liste_x[ii];
		    y=liste_y[ii];
		    c=im_in[x+width*y];
		    if(iflag) c_i=im_in_i[x+width*y];
		    //added by anu//
		    mean_im += c;
		    if(iflag) mean_im_i += c_i; 
		    if(min_im>c) min_im=c;
		    if(max_im<c) {max_im=c; x_peak=x; y_peak=y;} 
		}
		
		mean_im /=  (double)n_liste;
		if(iflag)  mean_im_i /=  (double)n_liste;

		//extreme points of the arc, area,peak position, peak flux, mean flux
		if(debug1) printf("#ext %i %i %i %i %i %i %i %lf %lf\n",x_min+x0,x_max+x0,y_min+y0,y_max+y0,n_liste,x_peak+x0,y_peak+y0,max_im,mean_im);

				//****Read the star/bad pixel MASK file, if provided *****		 
				if(imask==1)  mflag= im_mask[x_peak+width*(y_peak)]; 

		//**threshold
		//if(max_im < 100. &&  mean_im>0.1*sigma)
		if(max_im < max_imth &&  mean_im>mean_imth*sigma)
		    //$$ if(max_im < 500. &&  mean_im>2.*sigma)
		{

		    //**** Detection of edge points of the arc which is recovered based on****
		    //****the estimator threshold only**********
		    int xc,yc;
		    xc=(x_max+x_min)/2.;
		    yc=(y_max+y_min)/2.;
		    int pflg=1; 

		    //***Find a reference point situated outside arc which can be used to***
		    //***measure inclination of each point on the arc****
		    int nbr_x,nbr_y;
		    float mindist=1.E30;
		    for(ii=0;ii<n_liste;ii++)
		    {
			float ddist=pow(xc-liste_x[ii],2)+pow(yc-liste_y[ii],2);
			if(ddist<mindist){
			    nbr_x=liste_x[ii]; 
			    nbr_y=liste_y[ii]; 
			    mindist=ddist;
			}
		  // 9.0 is randomly chosen number
			if(fabs(1.*xc-1.*liste_x[ii])<=9. || fabs(1.*yc-1.*liste_y[ii])<=9.) 
			{
			    pflg=0;
			}
		    }
		  
		  // 55.0 is randomly chosen number
		    if(pflg==0 ){  
			float dybydx;
			if (xc==nbr_x && yc==nbr_y){
			  xc=xc+55.0; yc=yc+55.0;
			} 
			else if (xc==nbr_x && yc!=nbr_y){
			  xc=xc+55.0;
			} 
			else if(xc!=nbr_x && yc==nbr_y){
			  yc=yc+55.0;
			}
			else if(xc!=nbr_x && yc!=nbr_y){
			  dybydx=(yc-nbr_y)*1./(xc-nbr_x);
			  int sign=1;
			  if(xc<nbr_x&&xc>x_min){
				sign=-1;
			    }
			  xc=xc+sign*55.0;
			  yc=yc+sign*55.0*dybydx;
			}
		
		    }

		    float *ang;
		    int *num;
		    ang=malloc (sizeof(float)*(n_liste+1));
		    num=malloc (sizeof(int)*(n_liste+1));
		    for(ii=1;ii<=n_liste;ii++)
		    {
			// Calculate angle
			float cosang=10.0*(liste_x[ii-1]-xc)/(fabs(10.0)*sqrt(pow(liste_x[ii-1]-xc,2.)+pow(liste_y[ii-1]-yc,2.) ));
			if(cosang>1.) cosang=1.0;
			if(cosang<-1.) cosang=-1.0;
			ang[ii]=acos(cosang);
			if (liste_y[ii-1]<yc) ang[ii]=2*pi-ang[ii];
			num[ii]=ii-1;
			//fprintf(stderr,"Ang: %d %f %d \n",ii,ang[ii],num[ii]);
		    }


		    sort2(n_liste,ang,num);

		    //*** Detect the extreme points of the arc if the angle subtended by the***
		    //***two points wrt to the reference point is the largest***
		    float diffmin=-2*pi;
		    //int edge1,edge2;
		    int edge1=0,edge2=0;
		    float diff1,diff2;
		    
		    //int chki,chkim,chkip;
		    //chki=chkim=chkip=0;

		    for(ii=0;ii<n_liste;ii++)
		    {
			int chki=(ii+n_liste)%n_liste;
			int chkip=(ii+1+n_liste)%n_liste;
			int chkim=(ii-1+n_liste)%n_liste;
			diff1=fabs(ang[chki+1]-ang[chkim+1]);
			if(diff1>pi) diff1=2.0*pi-diff1;
			diff2=fabs(ang[chki+1]-ang[chkip+1]);
			if(diff2>pi) diff2=2.0*pi-diff2;
			if(fabs(diff2-diff1)>diffmin)
			{
			    edge1=ii+1; 
			    if(diff1>diff2) edge2=chkim+1;
			    if(diff1<diff2) edge2=chkip+1;
			    diffmin=fabs(diff2-diff1);
			}

		    }

		    float xext1=liste_x[num[edge1]];
		    float xext2=liste_x[num[edge2]];
		    float yext1=liste_y[num[edge1]];
		    float yext2=liste_y[num[edge2]];

		    free(ang);
		    free(num);


		    //***Calculate length of the arc and the radius r0_s - radius of an***
		    //***imaginary circle going through the arc******

		    float Ex, Ey, AB, AE, ED, CE, l_arc=0., cent_ang;
		    float c=0.0, ms=0.;   
		    ED=1.0e+22;
		    r0_s=200.; // 200 is randomly chosen

		    // coordinates of the end points of the arc
		    float del_x=(xext2-xext1);
		    float del_y=(yext2-yext1);

		    Ex=(del_x/2.0)+xext1; 
		    Ey=(del_y/2.0)+yext1;

		    ms=del_x/del_y;
		    //  if(fabs(del_y)<=1.) ms=del_x/(del_y+1.e-4);

		    AB=sqrt(del_x*del_x + del_y*del_y);
		    AE = AB/2;

		    int xb,yb;
		    for(ii=0;ii<n_liste;ii++)
		    { 
			if( fabs(liste_y[ii] - Ey + ms*(liste_x[ii]-Ex)) < 2.0)
			{ 
			    c= sqrt((liste_x[ii]-Ex)*(liste_x[ii]-Ex) + (liste_y[ii]-Ey)*(liste_y[ii]-Ey));
			    if (c<ED) { ED=c; xb=liste_x[ii]; yb=liste_y[ii];}
			}
			else if(fabs(Ex-liste_x[ii])<1. && fabs(Ey-liste_y[ii])<1.) 
			{
			    xb=liste_x[ii];
			    yb=liste_y[ii];
			    ED=0.; 
			    break;
			}
		    }
		    if(debug==2) printf("#xb,yb %f %f %f %f %i %i %f %f \n",xext1+x0,xext2+x0,yext1+y0,yext2+y0,xb+x0,yb+y0,del_x,del_y);
                    

		    if(ED==0. || ED>1000.)
		    {
			l_arc=AB; 
			r0_s=200;
			if(debug==2)  printf("#arc chord-length: %i %i %f %f\n",xb+x0,yb+y0,AB,r0_s);
		    }

		    if(ED>0 && ED<1000.)
		    {
			CE=AB*AB*0.25/ED;
			cent_ang=2*atan(2.*AE/(CE-ED));
			if(cent_ang<0.) cent_ang=cent_ang + 2*pi;
			l_arc=cent_ang*(CE+ED)/2;
			r0_s=(CE+ED)/2;
			if(debug==2)   printf("#arc chord-length: %i %i %f %f %f\n",xb+x0,yb+y0,AB,r0_s,cent_ang);
		    }
 		    

		    //***********Thresholds on length and width of an arc***************

		    //**threshold
		    //subw=0;    //$$subw=128;    
		    subw=subwth;

		    //if(l_arc>7. && l_arc>2.0*n_liste/l_arc) 
		    if(l_arc>l_arcth && l_arc>w_arcth*n_liste/l_arc) 
			//$$ if(l_arc>7. && l_arc>2.0*n_liste/l_arc) 
		    {

			//***Use pixels only if they are inside a boundary of 128 pixels from***
			//***all sides of the image - falls within the mask ***
			//This condition was used for SL2S images, may not be required in
			//other data sets. Change subw=0 (pixels) to any desired value, if you want
			//to clip off the image boundaries.
			borne1_x=xg_i-subw; if(borne1_x<0) borne1_x=0;
			borne2_x=xg_i+subw; if(borne2_x>width-1) borne2_x=width;
			borne1_y=yg_i-subw; if(borne1_y<0) borne1_y=0;
			borne2_y=yg_i+subw; if(borne2_y>height-1) borne2_y=height;
			if(borne2_x-borne1_x == 2*subw && borne2_y-borne1_y == 2*subw)
			{

			    //***Run, if second band image is provided***
			    int bcnt=0;
			    if (iflag) bcnt=ibandcalc(Ex,Ey,xb,yb,del_x,del_y,width,height,im_in,im_in_i,mean_im,mean_im_i);

			    //***Recovering rest of the "flesh" of the arc feature*** 
			    //*** applying thresholds on the flux from the pixels instead of using the***
			    //***elongation estimator**

			    for(ii=0;ii<n_liste;ii++)
			    {
				x=liste_x[ii];
				y=liste_y[ii];
				c=im_in[x+width*y];
				c_0=im0[x+width*y];
				mean_ratgi += c;
				mean_im0 += c_0;
			//old	if (debug) temp1[x+width*y]=c;
			    }
			    mean_ratgi /=  (double)n_liste;
			    mean_im0 /=  (double)n_liste;

			    //**threshold
			    //double crit1=1.5*mean_ratgi;	
			    //double crit2=1.2*mean_im0;
			    //int win=7;

			    double crit1=crit1th*mean_ratgi;	
			    double crit2=crit2th*mean_im0;
			    int win=winth;
			    int loopflag=0;

			    n_lisim=n_liste;
			    for(ik=0;ik<n_liste;ik++)
			    { 
				i0=liste_x[ik];
				j0=liste_y[ik];
				//Including pixels neighbour to the main skeleton of arc
				for(ii=0;ii<=-win;ii--)
				    for(jj=0;jj<=-win;jj--)
				    {
					loopflag=loopcalc(ii,jj,i0,j0,width,height,&n_lisim,n_liste,liste_x,liste_y,lisim_x,lisim_y,im2,im3,im_in,im0,flag1,crit1,crit2);
					if(loopflag) goto start;
				    } 

				for(ii=0;ii<=-win;ii--)
				    for(jj=0;jj<=win;jj++)
				    {
					loopflag=loopcalc(ii,jj,i0,j0,width,height,&n_lisim,n_liste,liste_x,liste_y,lisim_x,lisim_y,im2,im3,im_in,im0,flag1,crit1,crit2);
					if(loopflag) goto start;
				    } 

				for(ii=0;ii<=win;ii++)
				    for(jj=0;jj<=-win;jj--)
				    {
					loopflag=loopcalc(ii,jj,i0,j0,width,height,&n_lisim,n_liste,liste_x,liste_y,lisim_x,lisim_y,im2,im3,im_in,im0,flag1,crit1,crit2);
					if(loopflag) goto start;
				    } 

				for(ii=0;ii<=win;ii++)
				    for(jj=0;jj<=win;jj++)
				    {
					loopflag=loopcalc(ii,jj,i0,j0,width,height,&n_lisim,n_liste,liste_x,liste_y,lisim_x,lisim_y,im2,im3,im_in,im0,flag1,crit1,crit2);
					if(loopflag) goto start;
				    } 
			    } // ik

			    //****Final summing of all pixels belonging to the arc
			    //*** peak position and peak value
			    max_im=-1.e22;
			    for(ii=0;ii<n_lisim;ii++)
			    {
				x=lisim_x[ii];
				y=lisim_y[ii];
				c=im_in[x+width*y];
				if(max_im<c) {max_im=c; x_peak=x; y_peak=y;} 
			    }

			    //**** Final selection of the arc candidates ***    
			    //**threshold
  			    if(n_lisim>n_lisimth && max_im<max_imth &&  mean_im>mean_imth*sigma  && l_arc>w_arcth*n_lisim/l_arc &&  n_lisim/l_arc>=widminth && n_lisim/l_arc<=widmaxth )
				//if(n_lisim>35 && max_im<100. &&  mean_im>0.1*sigma  && l_arc>2.*n_lisim/l_arc &&  n_lisim/l_arc>=1.0 && n_lisim/l_arc<=15. )
				//$$ if(n_lisim>25 && max_im<500. && mean_im>2.*sigma && l_arc>2.*n_lisim/l_arc && n_lisim/l_arc>=1.5 && n_lisim/l_arc<=8.)
			    {
				c_i=0.; 
				float mval1;
				fprintf(cata1,"###### A%i ######\n",nbarc);
				for(ii=0;ii<n_lisim;ii++)
				{
				    x=lisim_x[ii];
				    y=lisim_y[ii];
				    c=im_in[x+width*y];
				    if(iflag) c_i=im_in_i[x+width*y];
				    dd=im[x+width*y];
				    im2[x+width*y]=0;
				    mean_im+=c;
				   	    if(imask==1) {
					    mval1=im_mask[x+x0+width*(y+y0)];
					    printf("%i %i %f \n",x+x0,y+y0,mval1);
					    }
                        if(iflag)  mean_im_i+=c_i;
				    if (iflag) fprintf(cata1,"%i %i %.3f %.3f %.3f\n", x+x0,y+y0,c, c_i,dd);
                    else fprintf(cata1,"%i %i %.3f %.3f\n", x+x0,y+y0,c,dd);
				    //fprintf(cata1,"%i %i %i \n", x+x0,y+y0,nbarc);
  			  	 if(debug)   temp1[x+width*y]=c;
				}
				nbarc++;
				mean_im /=  (double)n_lisim;
				if(iflag)  mean_im_i /=  (double)n_lisim;


				/******************Alpha-Delta AVEC APPEL CORRECT (i.e. x0 ET y0 ) *****/
				/* jfs_pix_to_angle(xg_i+x0,yg_i+x0); */
				jfs_pix_to_angle(x_peak+x0,y_peak+y0);
				/***********************************************************************/

				//int ix,jx;

				//added by anu//
				if(debug) printf("#Accepting: %i %i %lf %f %f %f %f %i \n",xg_i+x0,yg_i+y0,r0_s,mean_im/sigma,l_arc,n_lisim/l_arc,l_arc*l_arc/n_lisim, nbarc-1);

				fprintf(cata," %02i %02i %06.3lf  %c%02i %02i %05.2lf   %7i %5i   %5i %5.1f   %9.2lf %9.2lf %9.2lf   %9.2lf %9.2lf   %i \n",
					alphadelta_struct.ahi, alphadelta_struct.ami, alphadelta_struct.asd,
					"-+"[(alphadelta_struct.dsign+1)/2], 
					alphadelta_struct.ddi, alphadelta_struct.dmi, alphadelta_struct.dsd,
					x_peak+x0, y_peak+y0,
					n_lisim, r0_s, max_im, mean_im, mean_im_i, l_arc, n_lisim/l_arc, mflag);
				//RA,DEC,x,y,
				//area,r_circ,peakflux,integrated flux,integ. flux of second band (if provided), length, width, maskflag
			    } //final thresholds loop

			} //clip boundary loop

		    } //length of arc loop

		} //mean_imsig loop

	    } // n_liste loop

	} // j loop

    } // i loop
if(debug) 
{
    writefits(temp1, "ar_out.fits", width, height);
    printf("#Writing ar_out.fits \n");
}
//
printf("#Found %i candidates\n",nbarc-1);
fclose(cata);
fclose(cata1);
//if (icat==1) fclose(cata2);
} // main

//#########################################

//***IGNORE - below FEATURE NOT USED*** 
/*      *******co-ordinates xgc,ygc generated for comparison of red lens galaxies using two band info ***
	 int mn=17371,ib,jb;
	 float xgal[mn],ygal[mn],gmag[mn],imag[mn],gimag[mn];
	 float min[5],gimc[5],xgnc[5],ygnc[5];


	 if(icat==1)
	 {
	 sprintf(cata_name2,outname2);
	 cata2=fopen(cata_name2,"r");
	 for(ib=0;ib<mn;ib++)
	 {
	 fscanf(cata2,"%f %f %f",&xgal[ib],&ygal[ib],&gimag[ib]);
	 }
	 }


	 float xgc,ygc;
	 xgc=0.; ygc=0.;
	 if( r0_s==200.) { xgc=xb; ygc=yb;}
	 else 
	 {
	 if(fabs(del_y)<=1.) ms=del_x/(del_y+0.0001);

	 if(Ex>=xb && r0_s<50)  xgc=xb+(25/sqrt(1+(ms*ms)));
	 else if(Ex<xb && r0_s<50) xgc=xb-(25/sqrt(1+(ms*ms)));

	 if(Ex>=xb && r0_s>=50)  xgc=xb+(35/sqrt(1+(ms*ms)));
	 else if(Ex<xb && r0_s>=50) xgc=xb-(35/sqrt(1+(ms*ms)));

	 ygc=(ms*(xgc-xb)) + yb;
	 }

	 if(icat==1)
	 {
	 xgnc[0]=xgnc[1]=xgnc[2]=xgnc[3]=xgnc[4]=0.0; 
	 ygnc[0]=ygnc[1]=ygnc[2]=ygnc[3]=ygnc[4]=0.0; 
	 min[0]=9900.,min[1]=9901.,min[2]=9902.,min[3]=9903.,min[4]=9904;
	 for(ib=0;ib<mn;ib++)
	 {
//within a circle of radius 20 pix
if( pow(xgc+x0-xgal[ib],2.)+ pow(ygc+y0-ygal[ib],2.) <= 400.) 
{
if((l_arc/r0_s <= 1 && pow(xgc+x0-xgal[ib],2.)+ pow(ygc+y0-ygal[ib],2.) >=2.)|| l_arc/r0_s>1) 
{
if(gimag[ib]>=min[4]) continue;
int cgthis;
//Find the place in the min array//
for (jb=4;jb>0;jb--)
{
if(gimag[ib]<min[jb]&&gimag[ib]>=min[jb-1])
{
cgthis=jb;
break;
}
}
if(gimag[ib]<=min[0]) cgthis=0;
//Update the array//
for (jb=4;jb>cgthis;jb--)
{
min[jb]=min[jb-1];
xgnc[jb]=xgnc[jb-1];
ygnc[jb]=ygnc[jb-1];
}
min[cgthis]=gimag[ib];
xgnc[cgthis]=xgal[ib]; 
ygnc[cgthis]=ygal[ib];
}
}
} 
//gives the positions and magnitudes of 5 galaxies/objects in the vicinities 
//with the reddest listed as the first
//          printf("#magdiff: %f %f %f %f %f %f %f %f %f %f %f %f %f %f %f \n",xgnc[0],ygnc[0],min[0],xgnc[1],ygnc[1],min[1],xgnc[2],ygnc[2],min[2],xgnc[3],ygnc[3],min[3],xgnc[4],ygnc[4],min[4]);
} //icat
*/
//***IGNORE - above FEATURE NOT USED*** 

//********IGNORE - below FEATURE NOT USED****************
/*****to get rid of arc candidates within a bright object i.e, if a structure does not have smooth light distribution an arc is found at such places e.g. several detections within a star or a bright source/galaxy****************/
//double c1=0.,c2=0.,c3=0.,c4=0.; // bx=7; by=7; bcnt=0;
//***IGNORE - above FEATURE NOT USED*** 
