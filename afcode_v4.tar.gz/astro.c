#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc/malloc.h>
#include "types.h"

/*---------------------------- jfs_pix_to_angle ----------------------*/
void jfs_pix_to_angle(int X_pix,int Y_pix)
/* Routine qui prend des parametres d'une image FITS du CFHTLS,
   RefX_deg=CRVALn, RefX_pix=CRPIXn point de reference de l'image en degres et en pixel
   DegX_per_pix=CDn_n=echelle de l'image en Degres-par-Pixel
   et qui passe de coordonees X_pix en Pixels a xdd en Degres Decimaux
   via une projection TANGENTE (c'est A DIRE GNONOMIQUE) cf Calbretta et al. 2002 AA 395 1077 
   2006-02-09 v5.0 JFS Rectif Erreur (floor) +. (int) pour Delta qui peut etre negatif
   2006-04-04 v5.1 JFS Cosmetique
   2006-04-27 v6.0 JFS inclusion d un sign dans alphadelta_struct
*/
{
  /* dx, dy = pixels offset par rapport au ref point a0, d0 en alpha0, delta0 en radians   */
  /* xyz coordonees cartesienne du pointdu plan tangeant ou de sa projection sur la sphere */
  /* a,d angles en radiant du pointr projete sur la sphere */
  double dx, dy, a0, d0, x, y, z, a, d , r, xdd, ydd;
  /* XYZ X= x ou y = alpha  ou delta, Z= d ou i = decimale ou entiere */
  /*     Y= h ou d ou m ou s = heures ou degrees ou minutes ou secondes */
  double   xhd, xhi, xmd, xmi, xsd ;
  double ysign, ydi, ymd, ymi, ysd ;
  double pi= 3.141592654, rd_per_deg= pi/180. ;
  double RefX_deg, RefX_pix, DegX_per_pix ; 
  double RefY_deg, RefY_pix, DegY_per_pix ;

  RefX_deg=astro_struct.crval1;
  RefX_pix=astro_struct.crpix1;
  DegX_per_pix=astro_struct.cd1_1;
  /* IF CD1_2 != 0 STOP */
  RefY_deg=astro_struct.crval2;
  RefY_pix=astro_struct.crpix2;
  DegY_per_pix=astro_struct.cd2_2;
  /* IF CD2_1 != 0 STOP */

  /* calcul des coordonnes cartesienees du point */
  a0= RefX_deg * rd_per_deg ;
  d0= RefY_deg * rd_per_deg ;
  dx= (X_pix - RefX_pix) * DegX_per_pix * rd_per_deg ;
  dy= (Y_pix - RefY_pix) * DegY_per_pix * rd_per_deg ;
  x= (+cos(d0)*cos(a0)) + dx*(-sin(a0)) + dy*(-sin(d0)*cos(a0)) ;
  y= (+cos(d0)*sin(a0)) + dx*(+cos(a0)) + dy*(-sin(d0)*sin(a0)) ;
  z= (+sin(d0)        )                 + dy*(+cos(d0)        ) ;

  /* Projection Tangente i.e. Gnonomique */
  r= sqrt(x*x + y*y +z*z);
  x= x/r ;
  y= y/r ;
  z= z/r ;

  /* Calcule de Alpha Delta en radians puis en degrees */
  a= atan2(y,x) ;  if ( a < 0. ) a= a + (double)2.*pi ;
  d= atan2(z,sqrt(x*x + y*y)) ;
  xdd= a/rd_per_deg ;
  ydd= d/rd_per_deg ;

  /* Passage en heures decimales puis en hh:mm:ss.sss et dd:mm:ss.ss */
  xhd= xdd / 15. ;
  xhi= floor(xhd) ;
  xmd= (xhd - xhi) * 60. ;
  xmi= floor(xmd) ;
  xsd= (xmd - xmi) * 60. ;
  /* attention ydd peut etre negatif MAIS SE PLANTE SI ydd=0. */

 // Remi Cabanac introduced a security preventing a crash in case ydd=0 29/11/12  
  //  if (!(ydd==0.)) {  ysign= ydd / fabs(ydd);}
  // else {ysign = 1;}          
  // old was 
  // ysign= ydd / fabs(ydd); 

  if (!(ydd==0.)) {
  ysign= ydd / fabs(ydd);}
else {ysign = 1;}  
  ydd= fabs(ydd) ;
  ydi= floor(ydd) ;
  ymd= (ydd - ydi) * 60. ;
  ymi= floor(ymd) ;
  ysd= (ymd - ymi) * 60. ;

  /* Sorties pour impressions */
  alphadelta_struct.ahi= (int)xhi  ;
  alphadelta_struct.ami= (int)xmi  ;
  alphadelta_struct.asd= xsd  ;
  alphadelta_struct.dsign= (int)ysign;
  alphadelta_struct.ddi= (int)ydi  ;
  alphadelta_struct.dmi= (int)ymi  ;
  alphadelta_struct.dsd= ysd  ;

  if(!(alphadelta_struct.dsign==1 || alphadelta_struct.dsign==-1) )
  {
      printf("WARNING: Missing keywords in FITS header \n");
  //See the astro_struct_def in "types.h" for which keywords are needed
  }
		    
  /*   PRINT A LA xy2sky */
  /* 
  printf ( "%02i:%02i:%06.3lf %c%02i:%02i:%05.2lf JFS   %5i      %5i     \n", 
	   alphadelta_struct.ahi, alphadelta_struct.ami, alphadelta_struct.asd,
	   "-+"[(alphadelta_struct.dsign+1)/2], 
	   alphadelta_struct.ddi, alphadelta_struct.dmi, alphadelta_struct.dsd,
	   X_pix, Y_pix ) ;
  */
  
  return;
}
