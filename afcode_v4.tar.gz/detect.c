#include<stdio.h>
#include<string.h>
#include<malloc/malloc.h>
#include<stdlib.h>
#include "types.h"
#include<math.h>
#include<time.h>
#ifdef _OPENMP
	#include<omp.h>
#else
	#define omp_get_num_threads() 0
	#define omp_get_thread_num() 0
#endif

float *detect(DATA_TYPE *im,int width,int height,char *im_l,double sigma, char *thname)
{
    int    i,j,k,l,n,mesh,mesh2,xr,yr,i2,j2,nbat;
    double c,*buffw,*buffw_s,*buffh,*buffh_s,max,
	   mxx,myy,mxy,**sub,cg,sin_t,cos_t,*sub_x,*sub_y;
    float  *temp,seuil;
    char   name[256];
    int    nint(double x);

    int debug=0;

    //**threshold
    mesh=1;
    mesh2=mesh*2;

    int nbatth;
    float seuilth;
    int jnk1;
    float jnk;

    FILE *cata;
    cata=fopen(thname,"r");
    fscanf(cata,"%i %f %i %i %f %i",&jnk1,&jnk,&jnk1,&nbatth,&seuilth,&debug);
    fclose(cata);

    nbat=nbatth ;
    seuil=sigma*(2*nbat+1)*seuilth;

    printf("#Input thresholds for the estimator: %i %g %i \n",nbatth,seuilth,debug);
    //EUCLID
    // nbat=7 ;
    // seuil=sigma*(2*nbat+1)*0.05;

    //CFHT settings
    /*  
	mesh=1;
	mesh2=mesh*2;
	nbat=5 ;
	seuil=sigma*(2*nbat+1)*0.75;
     */

    im_l = (char *)malloc(width*height*sizeof(char));
    temp=(float *)malloc(width*height*sizeof(float));
    /*initialising im_l=0 will calculate the estimator only for pixels which give
     * local maxima which is good to speed-up calculation for large images, for
     * small images one can set im_l=1 */
    for(i=0;i<width*height;i++) im_l[i]=0;
    /***Attention Modif pour calculer la carte partout !****/

    /*************************************************************************************/
    /************ Recherche des maximas locaux par ligne et par colonne ******************/
    /*************************************************************************************/
    printf("#Looking for elongated features \n");

    //// #pragma omp parallel private(tid) shared(a,b,c)

    // shared : those variables which are shared between the threads/processors
    // private: those variables which the individual processors need separately
    n=0;
    clock_t t0, t1;
    t0=clock();
    #pragma omp parallel private(buffw,c,i,j,k,buffw_s,max,buffh,buffh_s,mxx,myy,mxy,i2,j2,cg,sin_t,cos_t,xr,yr,sub,sub_x,sub_y) shared(mesh,width,height,im,im_l,temp,nbat,seuil)
    {
	buffw = (double *)malloc(height*sizeof(double));
	buffw_s = (double *)malloc(height*sizeof(double));
	buffh = (double *)malloc(width*sizeof(double));
	buffh_s = (double *)malloc(width*sizeof(double));
	sub=(double **)malloc((nbat*2+1)*sizeof(double *));
	for(i=0;i<nbat*2+1;i++) sub[i]=(double *)malloc((nbat*2+1)*sizeof(double));
	sub_x = (double *)malloc((2*nbat+1)*sizeof(double));
	sub_y = (double *)malloc((2*nbat+1)*sizeof(double));
	//printf("%d: Hi from:%d\n ",i,omp_get_thread_num());

	#pragma omp for 
	for(i=mesh;i<width-mesh;i++)
	{
	    //printf("%d: Hi from:%d\n ",i,omp_get_thread_num());
	    //if((i/100)*100 == i) printf("#detect: %i\n",i);

	    for(j=0;j<height;j++) buffw[j]=im[i+width*j];

	    for(j=mesh;j<height-mesh;j++)
	    {
		for(c=0.0,k=-mesh;k<=mesh;k++) c += buffw[j+k];
		buffw_s[j]=c;
	    }

	    for(j=mesh;j<height-mesh;j++)
	    {

		max=buffw_s[j-mesh];
		for(k=-mesh+1;k<=mesh;k++) if(buffw_s[j+k]>max) max=buffw_s[j+k];
		if(buffw_s[j] == max && buffw_s[j]>0.0)
		    im_l[i+width*j]=1;

	    }
	}
	free(buffw);
	free(buffw_s);
        #pragma omp barrier

	#pragma omp for 
	for(j=mesh;j<height-mesh;j++)
	{
	    for(i=0;i<width;i++) buffh[i]=im[i+width*j];

	    for(i=mesh;i<width-mesh;i++)
	    {
		for(c=0.0,k=-mesh;k<=mesh;k++) c += buffh[i+k];
		buffh_s[i]=c;
	    }

	    for(i=mesh;i<width-mesh;i++)
	    {
		max=buffh_s[i-mesh];
		for(k=-mesh+1;k<=mesh;k++) if(buffh_s[i+k]>max) max=buffh_s[i+k];
		if(buffh_s[i] == max && buffh_s[i]>0.0)
		    im_l[i+width*j]=1;
	    }
	}
	free(buffh);
	free(buffh_s);

	#pragma omp for 
	for(i=0;i<width*height;i++) temp[i]=0.0;
	
	/************ Estimating second order moments****************************************/
	#pragma omp for 
	for(i=nbat;i<width-nbat;i++)
	{
	    if((i/500)*500 == i) printf("#detect2: %i\n",i);
	    for(j=nbat;j<height-nbat;j++)
	    {

		if(im_l[i+width*j])
		{
		    mxx=myy=mxy=0.0;
		    for(i2=-nbat;i2<=nbat;i2++)
			for(j2=-nbat;j2<=nbat;j2++)
			{
			    mxx += im[i+i2+width*(j+j2)]*i2*i2;
			    myy += im[i+i2+width*(j+j2)]*j2*j2;
			    mxy += im[i+i2+width*(j+j2)]*i2*j2;
			}

		    cg = -(-myy*0.5 + mxx*0.5 - sqrt(myy * myy - 2.0 * mxx * myy + mxx * mxx +(4.0 * mxy * mxy))*0.5) / mxy;

		    sin_t=cg/sqrt(1.0+cg*cg);
		    cos_t=sqrt(1.0-sin_t*sin_t);

		    
		    /*********Aligning the direction of the marginal distribution along the x-axis****************************/
		    
		    for(i2=-nbat;i2<=nbat;i2++)
			for(j2=-nbat;j2<=nbat;j2++)
			{
			    xr=nint(i2*cos_t-j2*sin_t+i);
			    yr=nint(i2*sin_t+j2*cos_t+j);
			    if(xr>-1 && xr<width && yr>-1 && yr<height)
				sub[i2+nbat][j2+nbat]=im[xr+yr*width];
			    else
				sub[i2+nbat][j2+nbat]=0;
			}

		    max=-1.0e22;
		    for(k=0;k<nbat*2+1;k++)
		    {
			for(c=0.0,l=0;l<2*nbat+1;l++) c += sub[k][l];
			sub_y[k] = c;

			if(c>max) max=c;
			// for(c=0.0,l=0;l<2*nbat+1;l++) c += sub[l][k];
			// sub_x[k] = c;

		    }

		    for(c=0.0,l=0;l<2*nbat+1;l++) c += sub[l][nbat];
		    sub_x[nbat]=c;
		    if(sub_x[nbat]>seuil && max>seuil) { temp[i+width*j]=sub_x[nbat]/max;}
		} 
	    } //end of j
	} // end of i
	for(i=0;i<nbat*2+1;i++) free(sub[i]);
	free(sub);
	free(sub_x);
	free(sub_y);
    } //parallel block
    printf("#Threshold used on the elongation estimator: %g \n",seuil); 

    t1=clock();
    printf("#Timing: %f \n", (const float)(t1-t0)/CLOCKS_PER_SEC);

    /* To visualise how the output looks like, create the following fits file */ 
    if(debug) 
    {
	writefits(temp, "ar_dt.fits", width, height);  
	printf("#Writing ar_dt.fits \n");
    }
    
    return temp;
}

int nint(double x)
{
    if (x-floor(x)<0.5) return (int)floor(x);
    else return (int)ceil(x);
}
