/* 2006-04-27 v2.0 JFS inclusion d un sign dans alphadelta_struct */

typedef struct
{
    double crval1;
    double crpix1;
    double cd1_1;
    double cd1_2;
    double crval2;
    double crpix2;
    double cd2_1;
    double cd2_2;
} astro_struct_def;

/* alpha=ahi:ami:asd delta=(dsign)ddi:dmi:dsd */
typedef struct
{
    int    ahi, ami;
    double asd;
    int    dsign, ddi, dmi;
    double dsd;
} alphadelta_struct_def;

#define DATA_TYPE float

astro_struct_def       astro_struct;
alphadelta_struct_def  alphadelta_struct ;

char prout;


DATA_TYPE *read_image(char *,int , int ,int ,int ,int ,int ,int ,double ,double,double *);
DATA_TYPE *readfits(char *name,int *width, int *height);
void writefits(DATA_TYPE *image, char *name,int width, int height);
void read_header(char *,int *width, int *height,int *bitpix,double *,double *,int fimg);
DATA_TYPE *detect(DATA_TYPE *im,int width,int height,char *im_l,double, char *);
DATA_TYPE *smooth(DATA_TYPE *im,int width,int height, char *);

//void connect(DATA_TYPE *,DATA_TYPE *,float *im0,float *im,int width,int height,int,int,double,char,char *,char *);

void connect_arc(DATA_TYPE *,DATA_TYPE *, DATA_TYPE *,DATA_TYPE *,DATA_TYPE *,int ,int ,int ,int ,double , char , char , char *, char *, char *, char *);

void jfs_pix_to_angle(int X_pix,int Y_pix);
