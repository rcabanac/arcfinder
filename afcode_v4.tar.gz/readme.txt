Version updates

V1 original code by C. Alard (2007)
V2 modified version by A. More (2012)
V3 modified version by R. Cabanac (2013)
V4 modified version by R. Cabanac (07/2014)

*******************************

Version 4:

In routine read_imagewosg.c: a new average sigma clipping algorithm is used to compute background noise (clipping at delta(sky) < 0.001)

******************************

Version 3:

small bug corrected in connect.c on a division by zero error


******************************

Version 2:

Major update, commented in the detect.c and connect.c routines.
