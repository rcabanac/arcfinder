#include<stdio.h>
#include<math.h>
#include<malloc/malloc.h>
#include<stdlib.h>
#include "fitsio.h"

#include "types.h"


#define short_type short
#define   swap_flag   0

//function to changed the endianness of the bytes
void reorder( char *buffer, int size ) {
       int i;
       char tmp;


       for ( i = 0; i < (size/2); i++ ) {
               tmp = buffer[i];
               buffer[i] = buffer[size - i - 1];
               buffer[size - i - 1] = tmp;
       }
}

DATA_TYPE *read_image(char *fname,int width, int height,int s_width,int s_height,int x0,int y0,int bitpix,double bscale,double bzero,double *sigma)
{
    int        i,j,hist[201],i_demi_1,i_demi_2,max_h, iter, k;
    DATA_TYPE  *image;
    float		sig, average, sig1, ave;
    double     hmean,sum;

    fitsfile *fptr;

    // by how much to increment the read pointer i.e read every inc-th pixel
    long inc[2];
    inc[0] = inc[1] = 1;
    
    //set undefined pixels in the image to 0
    float nulval=0;

    int anynul,status;
    // if the process works then status=0
    status=0;
    
    //printf("readimg %i %i %i %i \n",x0,y0,s_width,s_height);
    // bottom left and top right corners of the image to be read
    long fpixel[2],lpixel[2];
    fpixel[1]=y0;
    fpixel[0]=x0;
    
    if(y0==1) lpixel[1]=s_height;
    else lpixel[1]=y0+s_height-1;
    if(x0==1) lpixel[0]=s_width;
    else lpixel[0]=x0+s_width-1;

    //fprintf(stderr,"blc and trc %i %i %i %i \n",fpixel[0],fpixel[1],lpixel[0],lpixel[1]);
    
    image = (DATA_TYPE *)malloc(s_width*s_height*sizeof(DATA_TYPE));
    for( i=0;i<s_width*s_height;i++){image[i]=-99.0; }
  
    if ( fits_open_file( &fptr, fname, READONLY, &status ) ) 
    {
	printf("Cannot open file: %s\n", fname);
	exit(0);
    }
     
    if (fits_read_subset(fptr,TFLOAT,fpixel,lpixel,inc,&nulval,image,&anynul,&status))
    {
	printf("Cannot read file: %s %i\n", fname,status);
	exit(0);
    }
    
  //writefits(image, "ar_rd.fits", s_width, s_height);  
    
    // whether or not to swap the format in which data is stored in each byte of the pixel i.e endian system
    if(swap_flag)
    {  
	//if the input image is little endian, it will change it to big endian
	//or viceversa
	int bp=(bitpix<0)?-bitpix:bitpix;
	bp=bp/8;
	for(i=0;i<s_width*s_height;i++)
	{
	    reorder((char *)&image[i],bp);
	}
    }
    
    for(i=0;i<s_width*s_height;i++) 
    {
	image[i]=image[i]*bscale+bzero;
  	//printf("img is %f \n",image[i]);
    }

    if(*sigma<-98.)
    {
    sig=100000.;

	ave=0.;
	average=0.;
	for (k=0; k<50; k++) {
		iter = 0;
		for(i=0;i<s_width*s_height;i++) { 
			if (image[i]<ave+3.*sig) {
				iter++;
				average += image[i];
			}
		}
		average /= iter;
		ave = average;
		//printf("# %d average average+3.*sig : %g %d %g \n",k, ave, iter, average+3.*sig);
		sig1=0;
		iter=0;
		for(i=0;i<s_width*s_height;i++) { 	
			if (image[i]<ave+3.*sig) {
				iter++;
				sig1 += (image[i]-ave)*(image[i]-ave);
			}
		}
		sig1 = sqrt(sig1/iter);
		if (fabs(sig1-sig)/sig < 0.001) {sig = sig1; break;}
		sig=sig1;
		//printf("# %d sigma : %g %d\n",k,sig, iter);
	}

	*sigma = (double)sig;
	

	printf("#Sigma of the image: %g \n",*sigma);
    }
    else
    {
	printf("#User-defined sigma: %g \n",*sigma);
    }
    
    
    if ( fits_close_file(fptr, &status ) ) 
    {
	printf("Cannot close file: %s\n", fname);
	exit(0);
    }


    return image;
}
